﻿import ko from "knockout";

import * as Views from "PosApi/Create/Views";
import { ClientEntities, ProxyEntities } from "PosApi/Entities";
import { ObjectExtensions } from "PosApi/TypeExtensions";
import { IPostLogOnViewOptions } from "./NavigationContracts";

export default class PostLogOnView extends Views.CustomViewControllerBase {
    private _options: any;
    public backgroundImageEncodingURL: ko.Computed<string>;

    constructor(context: Views.ICustomViewControllerContext, options?: IPostLogOnViewOptions) {
        super(context);

        this.state.title = "PostLogOnView sample";
        this._options = options;

        this.backgroundImageEncodingURL = ko.computed(() => {
            return "url(disney-031-620x414.jpg)";
        }, this);
    }

    /**
     * Bind the html element with view controller.
     *
     * @param {HTMLElement} element DOM element.
     */
    public onReady(element: HTMLElement): void {
        ko.applyBindings(this, element);

        var btn = document.getElementById("confirmBtn");
        btn.addEventListener('click', () => {
            //this._confirmLogin();
            //this.context.navigator.navigateToPOSView("ShowJournalView");
            //let friend: ProxyEntities.Customer;
            //friend.AccountNumber = '004005';
            //this._viewFriendDetails(friend);

            const correlationId: string = this.context.logger.getNewCorrelationId();
            this.context.logger.logInformational("The view friend details button was clicked on the customer details friends panel.", correlationId);
            let customerDetailsOptions: ClientEntities.CustomerDetailsNavigationParameters
                = new ClientEntities.CustomerDetailsNavigationParameters("004005", correlationId);

            this.context.navigator.navigateToPOSView("CustomerDetailsView", customerDetailsOptions);
        });

        var carbtn = document.getElementById("cartBtn");
        carbtn.addEventListener('click', () => {
            this.context.navigator.navigateToPOSView("CartView");
        });
    }

    /**
     * Called when the object is disposed.
     */
    public dispose(): void {
        ObjectExtensions.disposeAllProperties(this);
    }

    /**
     * Confirm login.
     */
    public _confirmLogin(): void {
        this._options.resolveCallback();
    }

    public _viewFriendDetails(friend: ProxyEntities.Customer): void {
        const correlationId: string = this.context.logger.getNewCorrelationId();
        this.context.logger.logInformational("The view friend details button was clicked on the customer details friends panel.", correlationId);
        let customerDetailsOptions: ClientEntities.CustomerDetailsNavigationParameters
            = new ClientEntities.CustomerDetailsNavigationParameters(friend.AccountNumber, correlationId);

        this.context.navigator.navigateToPOSView("CustomerDetailsView", customerDetailsOptions);
    }
}
