System.register(["PosApi/Create/Operations"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Operations_1, RefundTerminalTenderLineToCartRequest;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Operations_1_1) {
                Operations_1 = Operations_1_1;
            }
        ],
        execute: function () {
            RefundTerminalTenderLineToCartRequest = (function (_super) {
                __extends(RefundTerminalTenderLineToCartRequest, _super);
                function RefundTerminalTenderLineToCartRequest(correlationId, tenderLine) {
                    var _this = _super.call(this, 6010, correlationId) || this;
                    _this.tenderLine = tenderLine;
                    return _this;
                }
                return RefundTerminalTenderLineToCartRequest;
            }(Operations_1.ExtensionOperationRequestBase));
            exports_1("default", RefundTerminalTenderLineToCartRequest);
        }
    };
});
//# sourceMappingURL=C:/D/g1/g4/NewCommerceSDK/POS_Samples/Solutions/SampleExtensions/Pos/Create/Operations/RefundTerminalTenderLineToCart/RefundTerminalTenderLineToCartRequest.js.map