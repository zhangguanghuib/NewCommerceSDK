System.register(["./RefundTerminalTenderLineToCartRequest"], function (exports_1, context_1) {
    "use strict";
    var RefundTerminalTenderLineToCartRequest_1, getOperationRequest;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (RefundTerminalTenderLineToCartRequest_1_1) {
                RefundTerminalTenderLineToCartRequest_1 = RefundTerminalTenderLineToCartRequest_1_1;
            }
        ],
        execute: function () {
            getOperationRequest = function (context, operationId, actionParameters, correlationId) {
                var tenderLine = null;
                var operationRequest = new RefundTerminalTenderLineToCartRequest_1.default(correlationId, tenderLine);
                return Promise.resolve({
                    canceled: false,
                    data: operationRequest
                });
            };
            exports_1("default", getOperationRequest);
        }
    };
});
//# sourceMappingURL=C:/D/g1/g4/NewCommerceSDK/POS_Samples/Solutions/SampleExtensions/Pos/Create/Operations/RefundTerminalTenderLineToCart/RefundTerminalTenderLineToCartFactory.js.map