System.register(["./CheckGiftCardBalanceRequest"], function (exports_1, context_1) {
    "use strict";
    var CheckGiftCardBalanceRequest_1, getOperationRequest;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (CheckGiftCardBalanceRequest_1_1) {
                CheckGiftCardBalanceRequest_1 = CheckGiftCardBalanceRequest_1_1;
            }
        ],
        execute: function () {
            getOperationRequest = function (context, operationId, actionParameters, correlationId) {
                var operationRequest = new CheckGiftCardBalanceRequest_1.default(correlationId);
                return Promise.resolve({
                    canceled: false,
                    data: operationRequest
                });
            };
            exports_1("default", getOperationRequest);
        }
    };
});
//# sourceMappingURL=C:/D/g1/g4/NewCommerceSDK/POS_Samples/Solutions/SampleExtensions/Pos/Create/Operations/CheckGiftCardBalance/CheckGiftCardBalanceFactory.js.map