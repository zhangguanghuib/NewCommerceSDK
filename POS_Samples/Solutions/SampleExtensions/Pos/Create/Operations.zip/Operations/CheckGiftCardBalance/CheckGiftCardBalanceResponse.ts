﻿
import { Response } from "PosApi/Create/RequestHandlers";

export default class CheckGiftCardBalanceResponse extends Response {
}