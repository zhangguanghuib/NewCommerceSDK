System.register(["PosApi/Create/Operations", "../../Dialogs/GiftCardBalanceDialog/GiftCardBalanceDialog", "../../Dialogs/GiftCardNumberDialog", "./CheckGiftCardBalanceRequest", "./CheckGiftCardBalanceResponse"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Operations_1, GiftCardBalanceDialog_1, GiftCardNumberDialog_1, CheckGiftCardBalanceRequest_1, CheckGiftCardBalanceResponse_1, CheckGiftCardBalanceHandler;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Operations_1_1) {
                Operations_1 = Operations_1_1;
            },
            function (GiftCardBalanceDialog_1_1) {
                GiftCardBalanceDialog_1 = GiftCardBalanceDialog_1_1;
            },
            function (GiftCardNumberDialog_1_1) {
                GiftCardNumberDialog_1 = GiftCardNumberDialog_1_1;
            },
            function (CheckGiftCardBalanceRequest_1_1) {
                CheckGiftCardBalanceRequest_1 = CheckGiftCardBalanceRequest_1_1;
            },
            function (CheckGiftCardBalanceResponse_1_1) {
                CheckGiftCardBalanceResponse_1 = CheckGiftCardBalanceResponse_1_1;
            }
        ],
        execute: function () {
            CheckGiftCardBalanceHandler = (function (_super) {
                __extends(CheckGiftCardBalanceHandler, _super);
                function CheckGiftCardBalanceHandler() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                CheckGiftCardBalanceHandler.prototype.supportedRequestType = function () {
                    return CheckGiftCardBalanceRequest_1.default;
                };
                CheckGiftCardBalanceHandler.prototype.executeAsync = function (request) {
                    var giftCardNumberDialog = new GiftCardNumberDialog_1.default();
                    return giftCardNumberDialog.show(this.context, request.correlationId)
                        .then(function (result) {
                        if (result.canceled) {
                            return Promise.resolve({ canceled: true, data: null });
                        }
                        var giftCardBalanceDialog = new GiftCardBalanceDialog_1.default();
                        return giftCardBalanceDialog.open(result.data).then(function () {
                            return Promise.resolve({ canceled: false, data: new CheckGiftCardBalanceResponse_1.default() });
                        });
                    });
                };
                return CheckGiftCardBalanceHandler;
            }(Operations_1.ExtensionOperationRequestHandlerBase));
            exports_1("default", CheckGiftCardBalanceHandler);
        }
    };
});
//# sourceMappingURL=C:/D/g1/g4/NewCommerceSDK/POS_Samples/Solutions/SampleExtensions/Pos/Create/Operations/CheckGiftCardBalance/CheckGiftCardBalanceHandler.js.map