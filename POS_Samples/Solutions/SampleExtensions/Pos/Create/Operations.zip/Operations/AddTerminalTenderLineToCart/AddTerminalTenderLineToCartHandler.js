System.register(["PosApi/Create/Operations", "./AddTerminalTenderLineToCartRequest", "PosApi/Consume/Cart", "../../Dialogs/DialogSample/MessageDialog", "PosApi/Consume/Device", "PosApi/TypeExtensions"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var Operations_1, AddTerminalTenderLineToCartRequest_1, Cart_1, MessageDialog_1, Device_1, TypeExtensions_1, AddTerminalTenderLineToCartHandler;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Operations_1_1) {
                Operations_1 = Operations_1_1;
            },
            function (AddTerminalTenderLineToCartRequest_1_1) {
                AddTerminalTenderLineToCartRequest_1 = AddTerminalTenderLineToCartRequest_1_1;
            },
            function (Cart_1_1) {
                Cart_1 = Cart_1_1;
            },
            function (MessageDialog_1_1) {
                MessageDialog_1 = MessageDialog_1_1;
            },
            function (Device_1_1) {
                Device_1 = Device_1_1;
            },
            function (TypeExtensions_1_1) {
                TypeExtensions_1 = TypeExtensions_1_1;
            }
        ],
        execute: function () {
            AddTerminalTenderLineToCartHandler = (function (_super) {
                __extends(AddTerminalTenderLineToCartHandler, _super);
                function AddTerminalTenderLineToCartHandler() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                AddTerminalTenderLineToCartHandler.prototype.supportedRequestType = function () {
                    return AddTerminalTenderLineToCartRequest_1.default;
                };
                AddTerminalTenderLineToCartHandler.prototype.executeAsync = function (request) {
                    var _this = this;
                    var correlationId = this.context.logger.getNewCorrelationId();
                    var cart = null;
                    var deviceConfiguration = null;
                    var getCartRequest = new Cart_1.GetCurrentCartClientRequest();
                    var isValid = true;
                    return this.context.runtime.executeAsync(getCartRequest)
                        .then(function (result) {
                        if (!result.canceled) {
                            cart = result.data.result;
                            if (TypeExtensions_1.ObjectExtensions.isNullOrUndefined(cart) ||
                                !TypeExtensions_1.ArrayExtensions.hasElements(cart.CartLines)) {
                                MessageDialog_1.default.show(_this.context, "Cart is Empty").then(function () {
                                    return Promise.resolve({
                                        canceled: true,
                                        data: null
                                    });
                                });
                                isValid = false;
                            }
                            if (cart.TotalItems < 1) {
                                MessageDialog_1.default.show(_this.context, "Please add items to cart before proceeding").then(function () {
                                    return Promise.resolve({
                                        canceled: true,
                                        data: null
                                    });
                                });
                                isValid = false;
                            }
                        }
                        if (isValid) {
                            var getDeviceConfigurationRequest = new Device_1.GetDeviceConfigurationClientRequest();
                            return _this.context.runtime.executeAsync(getDeviceConfigurationRequest).then(function (result1) {
                                deviceConfiguration = result1.data.result;
                                return Promise.resolve({
                                    data: result1.data.result,
                                    canceled: false
                                });
                            });
                        }
                        return Promise.resolve({
                            canceled: true,
                            data: null
                        });
                    }).then(function (result) {
                        return _this.beginProcessingManualCardPayment("3", deviceConfiguration.Currency, cart.AmountDue, "VISA", cart.CustomerId);
                    }).then(function (result) {
                        var currentCart = result.data.result;
                        if (currentCart.AmountDue === 0) {
                            var concludeTransactionClientRequest = new Cart_1.ConcludeTransactionClientRequest(correlationId);
                            _this.context.runtime.executeAsync(concludeTransactionClientRequest);
                        }
                        else {
                            var refreshCartClientRequest = new Cart_1.RefreshCartClientRequest();
                            _this.context.runtime.executeAsync(refreshCartClientRequest);
                        }
                    }).then(function () {
                        _this.context.navigator.navigateToPOSView("CartView");
                        return Promise.resolve({
                            canceled: false,
                            data: null
                        });
                    }).catch(function (reason) {
                        return MessageDialog_1.default.show(_this.context, reason + '').then(function () {
                            return Promise.resolve({
                                canceled: true,
                                data: null
                            });
                        });
                    });
                };
                AddTerminalTenderLineToCartHandler.prototype.beginProcessingManualCardPayment = function (tenderTypeId, currency, amountTendered, cardType, customerId) {
                    var preProcessedTenderLine = {
                        Amount: amountTendered,
                        TenderTypeId: tenderTypeId,
                        Currency: currency,
                        CardTypeId: cardType,
                        IsPreProcessed: false,
                        IsDeposit: false,
                        IsVoidable: true,
                        Authorization: "<![CDATA[<?xml version=\"1.0\" encoding=\"utf-16\"?>\r\n<ArrayOfPaymentProperty xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">\r\n  <PaymentProperty>\r\n    <Namespace>MerchantAccount</Namespace>\r\n    <Name>AssemblyName</Name>\r\n    <ValueType>String</ValueType>\r\n    <StoredStringValue>Contoso.PaymentDeviceSample</StoredStringValue>\r\n    <DecimalValue>0</DecimalValue>\r\n    <DateValue>0001-01-01T00:00:00</DateValue>\r\n    <SecurityLevel>None</SecurityLevel>\r\n    <IsEncrypted>false</IsEncrypted>\r\n    <IsPassword>false</IsPassword>\r\n    <IsReadOnly>false</IsReadOnly>\r\n    <IsHidden>false</IsHidden>\r\n    <DisplayHeight>1</DisplayHeight>\r\n    <SequenceNumber>0</SequenceNumber>\r\n  </PaymentProperty>\r\n  <PaymentProperty>\r\n    <Namespace>Connector</Namespace>\r\n    <Name>ConnectorName</Name>\r\n    <ValueType>String</ValueType>\r\n    <StoredStringValue>TestConnector</StoredStringValue>\r\n    <DecimalValue>0</DecimalValue>\r\n    <DateValue>0001-01-01T00:00:00</DateValue>\r\n    <SecurityLevel>None</SecurityLevel>\r\n    <IsEncrypted>false</IsEncrypted>\r\n    <IsPassword>false</IsPassword>\r\n    <IsReadOnly>false</IsReadOnly>\r\n    <IsHidden>false</IsHidden>\r\n    <DisplayHeight>1</DisplayHeight>\r\n    <SequenceNumber>0</SequenceNumber>\r\n  </PaymentProperty>\r\n</ArrayOfPaymentProperty>]]>",
                        MaskedCardNumber: '411111****** 1111',
                        TransactionStatusValue: 0,
                        IncomeExpenseAccountTypeValue: -1,
                        CashBackAmount: 0,
                        AmountInTenderedCurrency: amountTendered,
                        AmountInCompanyCurrency: amountTendered,
                        ReasonCodeLines: [],
                        CustomerId: customerId,
                        IsChangeLine: false,
                        IsHistorical: false,
                        StatusValue: 2,
                        VoidStatusValue: 0,
                        ExtensionProperties: []
                    };
                    return this.addTenderToCart(preProcessedTenderLine);
                };
                AddTerminalTenderLineToCartHandler.prototype.addTenderToCart = function (preProcessedTenderLine) {
                    var _this = this;
                    var addPreProcessedTenderLineToCartClientRequest = new Cart_1.AddPreprocessedTenderLineToCartClientRequest(preProcessedTenderLine);
                    return this.context.runtime.executeAsync(addPreProcessedTenderLineToCartClientRequest)
                        .then(function (result) {
                        return result;
                    }).catch(function (reason) {
                        return MessageDialog_1.default.show(_this.context, reason).then(function () {
                            _this.context.logger.logInformational("MessageDialog closed");
                            return Promise.resolve({ canceled: true, data: null });
                        });
                    });
                };
                return AddTerminalTenderLineToCartHandler;
            }(Operations_1.ExtensionOperationRequestHandlerBase));
            exports_1("default", AddTerminalTenderLineToCartHandler);
        }
    };
});
//# sourceMappingURL=C:/D/g1/g4/NewCommerceSDK/POS_Samples/Solutions/SampleExtensions/Pos/Create/Operations/AddTerminalTenderLineToCart/AddTerminalTenderLineToCartHandler.js.map