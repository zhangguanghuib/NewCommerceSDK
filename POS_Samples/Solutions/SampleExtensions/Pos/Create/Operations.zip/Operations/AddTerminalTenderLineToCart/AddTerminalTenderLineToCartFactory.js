System.register(["./AddTerminalTenderLineToCartRequest"], function (exports_1, context_1) {
    "use strict";
    var AddTerminalTenderLineToCartRequest_1, getOperationRequest;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (AddTerminalTenderLineToCartRequest_1_1) {
                AddTerminalTenderLineToCartRequest_1 = AddTerminalTenderLineToCartRequest_1_1;
            }
        ],
        execute: function () {
            getOperationRequest = function (context, operationId, actionParameters, correlationId) {
                var tenderLine = null;
                var operationRequest = new AddTerminalTenderLineToCartRequest_1.default(correlationId, tenderLine);
                return Promise.resolve({
                    canceled: false,
                    data: operationRequest
                });
            };
            exports_1("default", getOperationRequest);
        }
    };
});
//# sourceMappingURL=C:/D/g1/g4/NewCommerceSDK/POS_Samples/Solutions/SampleExtensions/Pos/Create/Operations/AddTerminalTenderLineToCart/AddTerminalTenderLineToCartFactory.js.map